create
    definer = root@localhost procedure sp_sale(IN n int)
BEGIN
select p.id as id,p.name ,sum(od.num) as total,sum(od.num) * price as money 
FROM order_detail od,product_info p 
where p.id = od.p_id 
GROUP BY p.id,p.name,price ORDER BY total DESC ;
END;

